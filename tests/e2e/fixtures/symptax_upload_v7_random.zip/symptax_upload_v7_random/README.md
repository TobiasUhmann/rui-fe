# `Symptax Upload ZIP v7 (random)`

`Symptax Upload ZIP v7`, but with random data.

# Files

- `edges.txt`
  - Columns: head_node, tail_node, rel
  - Rel: 0 = parent, 1 = synonym

- `match.txt`
  - Columns: ticket_id, node, mention, mention_indexes, ticket_text
  - mention_indexes = consecutive pairs of start and end indexes

- `nodes.txt`
  - Row format: node_id node_dict
  - node_dict: {'entities': {ent_id: Entity}}
  - Entity(name: str, undesired_phrases: [str], undesired_pattern: [str])

- `parent.csv`
  - parent predictions, e.g. "Bei Rechnung [...]" has parent 62 "teil ist beschädigt"
  - score = model score, only meaningful in comparison to predictions about same (relation, tail)
  - score norm = score normalized to [0, 1], only meaningful in comparison to predictions about same (relation, tail)
  - predicted nid = predicted node ID
  - predicted node = nid:x:node_label, x = model internal ID (ignore)
  - relation = parent/synonym
  - candidate = tokenized context

- `synonym.csv`
  - same as `parent.csv`, but for synonyms
